# Canonical Project Archive v0.5 - 2026-09-03

This is the fossil-free checkpoint after the figure/specification numeral audit,
independent-claim limitation support audit, inventor-confirmation questionnaire,
and specification v0.4 corrections.

Canonical patent state:
- specification v0.4 - 280 numbered specification paragraphs + 135 claims + abstract;
- claims v0.4 - 135 working claims / 14 independent families / no ceiling;
- drawings v0.2 - FIGS. 1-12 and 111 audited reference-numeral entries;
- Patent Support and Figure Audit v0.2 - 63 limitation-level support rows;
- Inventor Confirmation Questionnaire v0.1;
- project tracker synchronized to this checkpoint.

Excluded as fossil/superseded material:
- all earlier specification versions;
- all earlier claim-universe versions;
- earlier master-control/status/roadmap versions;
- prior canonical/organized ZIP archives;
- figure v0.1;
- superseded Patent Support and Figure Audit v0.1;
- QA renders/contact sheets/previews;
- obsolete 20-claim planning and intermediate drafting files.

Integrity files:
- MANIFEST_SHA256.json
- MANIFEST_SHA256.csv
- SHA256SUMS.txt
